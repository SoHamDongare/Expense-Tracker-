from django.db import models

# Create your models here.
class Expense(models.Model):
    amount = models.FloatField()
    category = models.CharField(max_length=100)
    date = models.DateField()  
    description = models.TextField(blank=True)
    
    def __str__(self):
        return f"{self.category} - {self.amount}"