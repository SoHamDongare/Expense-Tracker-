from django.shortcuts import redirect, render, get_object_or_404
from django.db.models import Sum
from .models import Expense
# Create your views here.
def home(request): 
    expenses = Expense.objects.all()
    
    total_expense = expenses.aggregate(Sum('amount'))['amount__sum'] or 0
    
    category_summary = expenses.values('category').annotate(total=Sum('amount')).order_by('-total')
    context = {
        'expenses': expenses,
        'total_expense': total_expense,
        'category_summary': category_summary
    }
    
    return render(request, 'trackerapp/home.html', context)

def add_expense(request):
    if request.method == 'POST':
        data = request.POST
        amount = data.get('amount')
        category = data.get('category')
        date = data.get('date')
        description = data.get('description', '')
        
        Expense.objects.create(amount=amount, category=category, date=date, description=description)
        return redirect('home')
    return render(request, 'trackerapp/add_expense.html')

def delete_expense(request,id):
    expense =get_object_or_404(Expense, id=id)
    expense.delete()
    return redirect('home')